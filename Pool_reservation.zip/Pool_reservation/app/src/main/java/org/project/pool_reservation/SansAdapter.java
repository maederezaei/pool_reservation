package org.project.pool_reservation;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.ArrayList;

import java.util.List;

public class SansAdapter extends ArrayAdapter {
    private List<Sans> sans;
    public SansAdapter(@NonNull Context context, @NonNull List<Sans> sans) {
        super(context, R.layout.sans_item_list, sans);
        this.sans=sans;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        Sans san=sans.get(position);
        ViewHolder holder;
        if(convertView== null){
            LayoutInflater inflater= (LayoutInflater) getContext()
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.sans_item_list,parent,false);
            holder=new ViewHolder(convertView);
            convertView.setTag(holder);

        }else {

                holder= (ViewHolder) convertView.getTag();

        }
        holder.fill(san);
        return convertView;
    }
    private class ViewHolder implements View.OnClickListener {
        public TextView tv_time;
        public TextView tv_sex;
        public TextView tv_reserve;
        public Button btn_delete;
        public Button btn_edit;
        public ViewHolder(View converview ){
            if(converview!= null) {
                tv_time = converview.findViewById(R.id.time);
                tv_sex = converview.findViewById(R.id.sex);
                tv_reserve = converview.findViewById(R.id.reserve);
                btn_delete = converview.findViewById(R.id.delete);
                btn_edit = converview.findViewById(R.id.editText);
            }
            btn_edit.setOnClickListener(this);
            btn_delete.setOnClickListener(this);


        }

        public void fill(Sans sans){
            if(tv_time!=null)
                tv_time.setText(sans.getTime());
            if(tv_sex!=null)
                tv_sex.setText(sans.getSex());
            if(tv_reserve!=null)
                tv_reserve.setText("10");


        }

        @Override
        public void onClick(View view) {
            if(view.equals(btn_delete)){

            }else if(view.equals(btn_edit)){

            }

        }
    }
}
