package org.project.pool_reservation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import java.util.ArrayList;

public class owner_register extends AppCompatActivity {
    List<Sans> sans;
    ListView listView;
    SansAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_register);
        listView=findViewById(R.id.listView);
        sans=new ArrayList<>();


        sans.add(new Sans("12:30 - 13:30" ,"بانوان",20));
        sans.add(new Sans("14:00 - 15:00" ,"آقایان",12));
        sans.add(new Sans("16:00 - 17:00" ,"بانوان",8));
        sans.add(new Sans("18:25 - 19:15" ,"بانوان",15));
        sans.add(new Sans("21:30 - 22:30" ,"آقایان",25));
        adapter=new SansAdapter(this,sans);
        listView.setAdapter(adapter);
    }
    private void refreshDisplay() {

    }
    private void prepareDate() {

    }
/*  private ListView listView;
    private CustomAdapter customAdapter;
    private ArrayList<ContactModel> contactModelArrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_register);
        listView = (ListView) findViewById(R.id.listView);

        contactModelArrayList = new ArrayList<>();



            ContactModel contactModel = new ContactModel();
            contactModel.setName("ali");
            contactModel.setNumber("091029012");
            contactModelArrayList.add(contactModel);
        contactModel.setName("aldsfsdfi");
        contactModel.setNumber("09323232029012");
        contactModelArrayList.add(contactModel);


        customAdapter = new CustomAdapter(this,contactModelArrayList);
        listView.setAdapter(customAdapter);

    }*/
}

